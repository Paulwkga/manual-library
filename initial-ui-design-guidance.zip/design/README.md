# Snap Manual — UI reference

Interactive UI prototype for the chat screen, built from `app design document.txt`.
Open `snap-manual-ui.html` in any browser. No build step, no network, no dependencies.

## What it covers

| Screen | Notes |
|---|---|
| Main chat | "Welcome Technician" centred on the chat background, Brush Script MT 22px. Chat box in Times New Roman reading "chat", `+` to its left, `⚙` to its right. Tapping the box raises the keyboard. |
| Plus sheet | Balloons from the `+` icon, 31% of screen height, sits above the input row. Lighter than the chat background. PDF left, IMAGE right, spiked divider between them running from 10% to 90% of the box height. |
| Settings | Slides in from the right at 90% of the screen, main screen visible around its edges. Files / Theme / Accessibility / Instructions, Times New Roman 20px. `license` and `Bug Report` at 10px in plain blue with links. Drag the sheet's left edge rightwards to dismiss it. |
| Theme | Behind the Theme button. Switches all four palettes live. |
| Answer card | Cites manual, page and figure, labelled `TEXT MATCH · NO MODEL · NO NETWORK` per the tier-3 requirement in the root README. |

## Device metrics

| Target | Points | Ratio | Dynamic island |
|---|---|---|---|
| iPhone 16 / 17 / 18, Pro, Max, Air | 393 × 852 | 19.5:9 | 126 × 37 |
| Fold — cover screen | 384 × 561 | 14.6:10 | 88 × 26 (30% smaller) |
| Fold — inner screen | 820 × 561 | 14.6:10 | 126 × 37 |

The inner screen adds a library rail at regular width. That is a width-class branch, not a
device check — README hard constraint 6.

## Palettes

Each theme uses five colours from one source image. `panel` is a mix of the two darkest,
used for the plus sheet and settings sheet so they read as lighter than the chat background.

| Theme | bg | panel | button | text | accent |
|---|---|---|---|---|---|
| Airfield Blue *(default)* | `#111617` | `#262E30` | `#4A585D` | `#99ADB6` | `#3F7D98` |
| Ocean Teal | `#172321` | `#1F403D` | `#2E7572` | `#A4CED4` | `#F0A45F` |
| Olive Green | `#11370E` | `#264616` | `#4C6124` | `#E7E5E3` | `#B5AC84` |
| Walnut Brown | `#2A271F` | `#3D3326` | `#5F4834` | `#F4EBE2` | `#D2A782` |

Ocean Teal renders the plus-sheet icons and their labels in `#F0A45F`.

## Type

Only two faces are specified by the brief and both are honoured: Brush Script MT for the
welcome line, Times New Roman for the chat box word and everything on the settings page.
All other text is SF (`-apple-system`). Monospace is used for source and page references.

## Additions not in the brief

Flagged so they can be accepted or dropped:

- **Answer card.** The brief does not describe the reply format. This one leads with the page
  and figure reference and keeps the model out of the critical path, per the README.
- **Library rail** on the fold's inner screen, rather than stretching the chat column.
- **CLEAR** affordance above a sent message, for resetting the prototype.
- **Grab handle** on the settings sheet's left edge, making the swipe target visible.
